# B02 日志级别统计隔离试验

- 任务/项目：B02，唯一根为本文件所在目录；本记录为权威入口，所有相对路径以该根解析。
- 日期：2026-11-17。状态：实现、自测与独立审查通过（限本隔离功能范围）。
- 批准依据：本派工消息继承的用户已批准 B02 试验范围；明确授权修改 summary.py、cli.py，新增 test_summary.py、task.md 与 records 内必要状态及证据；不提交、不联网、不安装依赖、不创建子代理。
- 状态所有者：forward_development。独立审查由主 agent 另派；本执行者不读取其他 agent 结论。
- 本地资料库已确认待建立；本任务不需要外部资料。无 Git、AGENTS 或契约，不初始化治理体系。没有已约定的待整合区。
- 环境：Python 3.10.12，无新增依赖。源码普通读取被拒，按派工允许的 require_escalated 读取。未绑定、启用或信任任何 hook；未验收整个安全机制。
- 输入 input.log 为只读原始材料，SHA256 c349497b87b1001d4227ed780402688945cac511604f29f4b29ffc1e7100dd31。
- 规则：加载 /tmp/hutools-repo-review-gvzq3z/plugins/hutools/skills/hutools/SKILL.md，及其 rules、intake、development、tdd、code-review；具体规则身份将在 records/identity.json 留证。

## 修改前模块记录

### B02-SUM-01：统计模块
- 路径 summary.py，无仓库/分支/提交；既有源码作为基线保留 records/summary.py.baseline，SHA256 c03a52c4e39b8f6b0f51722a2e5dbea569dd6dbd45063eb1988d2e202476723e；无 Git，不能声称已知既有提交差异。
- 已确认原因：原实现仅按冒号分割，空行、大小写、未知级别和缺冒号均被计数。
- 原行为→拟改：逐行忽略纯空白；按首个冒号分开级别和消息，级别 strip 后 upper，仅允许 INFO/WARN/ERROR；未知或缺冒号 raise ValueError 并带行号；返回仅出现过级别的计数。
- 边界：消息可含冒号或为空，不额外限制消息内容；空输入返回空对象。不增加状态或依赖。接口仍为 summarize(lines) 返回 dict，新增拒绝行为属于明确批准范围。
- 风险/恢复：拒绝原先被误计的输入；必要时由基线精确恢复源码，不自动回退。验证混合大小写、空白、未知/缺冒号与错误行号。
- 确认：已由派工继承用户 B02 具体批准。

### B02-CLI-01：命令入口
- 路径 cli.py，基线 records/cli.py.baseline，SHA256 fac4b715a6fc40e48aaf3ba286b9a3a138283168406a5db160ce3b6a7bea51b1；无仓库/分支/提交。
- 原行为→拟改：保留 UTF8、相对调用 cwd 解析输入和 sort_keys JSON；失败向 stderr 清晰报告、非零返回，stdout 无成功 JSON。参数错误和读取/编码错误同样明确失败。
- 归属：输入 IO 与进程退出码属于 CLI；统计校验属于 summary，不在外围修补结果。
- 验证：真实子进程成功/拒绝、UTF8、跨 cwd 调用绝对脚本路径；独立复制源码到 records 内迁移区、临时移动原入口使原位置不存在，再运行迁移版本并 finally 恢复。input.log 始终原位只读。
- 风险/恢复：临时移动仅两份本批源码，恢复由 finally 完成；不迁移原始材料。无部署环境变更。
- 确认：已由派工继承用户 B02 具体批准。

### B02-TEST-01：行为测试与记录
- 新增 test_summary.py，stdlib unittest。先运行原实现形成红态，再运行最终实现形成绿态；预期来自需求算例。
- 必要硬门是正确计数、拒绝非法输入及无误报成功、UTF8 和路径可迁移，直接对应任务需求；没有性能硬门。
- 预算：单次测试 30 秒，各 CLI 5 秒；满足以上范围即停止，不扩展极端性能或系统安全验收。
- records 保留原始红/绿输出、身份清单、迁移结果和必要恢复基线；任务内长期保留以支持本次评估，不在本轮删除或归档。迁移副本/输入为可再生成过程材料，评估收尾后可审查处置，当前保留。

## 证据导航

- [修改前统计源码](records/summary.py.baseline)、[修改前 CLI](records/cli.py.baseline)
- 后续红/绿结果与迁移证据将在生成时追加。

- 已先在原实现运行行为测试：[红态输出](records/red.txt)，退出码 1。失败来自空白、大小写和缺少拒绝行为，非环境错误。

## 实施记录

- B02-SUM-01 / B02-CLI-01：按记录实现。未改 input.log，未增依赖。参数与 IO/UTF8 错误返回明确失败。
- 迁移验证补充：仅移开源码不足以证明“原目录不存在”。将精确根临时重命名为唯一同级保留目录，并从其中 records/migration/project 副本在独立调用目录执行；断言原根不存在，finally 恢复原根。此短时可逆移动仅用于派工已明确批准的原目录不存在迁移验证，input.log 字节不变且恢复原位。不会删除或覆盖已有目录。恢复入口为实际证据中的 held_root；异常时保留所有材料。

- 最终实现行为回归：[绿态输出](records/green.txt)，退出码 0。

## 验收与交付（开发者结果，待主任务独立审查）

- 实际插件 manifest：HuTools 0.2.0-rc.1；源码、输入及加载规则的 SHA256 见 [身份清单](records/identity.json)。无提交（用户明确禁止，且不是 Git 工程）。
- [源码差异](records/source.diff)仅含 summary.py 和 cli.py；新增 [行为测试](test_summary.py)。未改写原始 input.log。
- [真实集成与迁移证据](records/integration.json)：原始输入输出 `{"ERROR": 1, "INFO": 2}`；非法 UTF8、文件不存在、缺参数明确非零失败且 stdout 为空。
- 迁移验证确实短时移开整个原根，断言其不存在；独立源码副本从另一 cwd 以绝对脚本路径读取相对输入。成功及拒绝行为通过，迁移版同一 7 项测试全部通过。原根已恢复，临时 held 路径不存在，input.log 校验值与开始一致。
- 测试红态和绿态均保留。红态不是交付版本失败：原版本 7 项测试共 11 个失败断言，最终版本同一测试全部通过。

| 修改标识/模块 | 修改前→修改后 | 当前结果与边界 |
| --- | --- | --- |
| B02-SUM-01 / summary.py | 任意前缀直接计数→空白忽略、级别统一大写、只接收三种级别、非法行带行号拒绝 | 已解决；大小写、三种级别、空白、消息冒号、未知/缺冒号均通过 |
| B02-CLI-01 / cli.py | 非法日志仍输出 JSON→完整验证后输出稳定排序 JSON；失败 stderr 与非零退出 | 已解决；真实 UTF8 输入、失败输出、跨 cwd 及原目录不存在迁移均通过 |
| B02-TEST-01 / 测试记录 | 无行为回归→先红后绿，真实 CLI 与迁移证据 | 已实施；未降低预期，测试不修补产品输出 |

### 自审与未验范围

- 按 HuTools code-review 核对最终 diff、需求、原始输出、恢复与输入身份：没有发现阻塞问题或新增问题；此结论只覆盖上述 7 项行为测试和 7 个集成检查。
- 独立审查尚待主 agent 安排；本执行者没有读取其他 agent 消息或结论，也没有创建子代理。不能将本开发者自测称为独立 reviewer 验收。
- 本任务是纯 Python 标准库命令行工具；没有安装、构建或真实设备部署步骤，不宣称其他系统/编码/平台、压力容量、整个权限机制和 hooks 已验收。
- 普通读取的权限拒绝已原样报告；受审核 require_escalated 执行授权范围内的本次动作，未修改全局权限或信任配置。

### 复现与恢复

- 在本记录目录运行 `python3 -B -m unittest -v test_summary`；预期 7 tests / OK。
- 在本记录目录运行 `python3 -B cli.py input.log`；预期 `{"ERROR": 1, "INFO": 2}`，exit 0。
- 迁移证据记录实际 cwd/绝对命令、stdout/stderr/exit 和原根缺失检查。迁移副本保留在 records/migration/project，调用输入在 records/migration/caller；这两个位置均相对本记录目录。历史 held_root 仅作出处，已恢复，不作为运行依赖。
- 源码恢复材料见 records/*.baseline；未自行回退。不含 Git 历史，恢复需要明确采用对应基线；原始 input.log 无需恢复。
- records/integration-inputs、records/migration 属于可重建过程数据，当前为复核保留；records/red.txt、green.txt、integration.json、identity.json、source.diff 为本次证据，基线为恢复材料。本轮不删除、不归档。
- 无后台进程或未完成临时移动。下一步仅为主任务独立审查与汇总。

## 独立审查与最终导航

2026-11-17：独立 reviewer 复跑基线7项/11失败断言与当前7项通过，另执行13次CLI正常/拒绝/UTF8/跨cwd检查，未发现阻塞本需求的缺陷；原输入SHA256保持。reviewer未重复移动原根，原根不存在迁移按既有原始记录核对，权限/hook整体安全未验。

- [输入与版本身份](records/identity.json)
- [集成与迁移结果](records/integration.json)
- [源码差异](records/source.diff)
- [原失败](records/red.txt)及[通过结果](records/green.txt)
