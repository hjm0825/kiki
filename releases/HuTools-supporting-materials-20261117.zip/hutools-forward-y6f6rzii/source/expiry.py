def should_drop(sent_at_ms, received_at_ms, ttl_seconds):
    return received_at_ms - sent_at_ms > ttl_seconds
